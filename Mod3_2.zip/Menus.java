
import java.awt.EventQueue;
import java.awt.Color;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Menus extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel thePanel;
	private static JMenuBar menuBar;
	private JMenu menu;
	private JMenuItem menuItem;
	private JMenuItem menuItem1;
	private JMenuItem menuItem2;
	private JMenuItem menuItem3;
	private JTextField text;

	
	public static Color randColor(){
		int r = 0;
		int g = (int)(Math.random()*256);
		int b = 0;
		
		return (new Color(r,g,b));
	}
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Menus frame = new Menus();
					frame.setVisible(true);
					frame.setJMenuBar(menuBar);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Menus() {
		setTitle("Menus Practice");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 280, 227);
		thePanel = new JPanel();
		thePanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		thePanel.setBackground(randColor());
		
		setContentPane(thePanel);
		
		text = new JTextField();
		text.setBounds(82, 100, 86, 20);
		thePanel.add(text);
		text.setColumns(15);
		
		menuBar = new JMenuBar();
		menu = new JMenu("Menu");
		menuItem = new JMenuItem("Date & Time");
		menuItem1 = new JMenuItem("Write to file");
		menuItem2 = new JMenuItem("Change color");
		menuItem3 = new JMenuItem("Exit");
		
		menu.add(menuItem);
		menu.add(menuItem1);
		menu.add(menuItem2);
		menu.add(menuItem3);
		menuBar.add(menu);
		
		menuItem.addActionListener(new ActionListener() {
			//@Override
			public void actionPerformed(ActionEvent e) {
				// print date
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
				LocalDateTime now = LocalDateTime.now();
				text.setText(dtf.format(now));
			}
			
		});
		
		menuItem1.addActionListener(new ActionListener(){
			//	@Override
			public void actionPerformed(ActionEvent e) {
				// write to file
				DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
				LocalDateTime now = LocalDateTime.now();
				try {
					FileWriter writer = new FileWriter("C:/Users/maste/OneDrive/Documents/CSU Global/Java 2/mod 3/textfile.txt");
					writer.write(dtf.format(now));
					writer.close();
				}
				catch (IOException e1) {
					System.out.print(e1.getMessage());
				}
			}
		});
		
		menuItem2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				thePanel.setBackground(randColor());
			}
		});
		
		menuItem3.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				System.exit(0);
			}
		});
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// app gets mad if this method is not here
	}
}

